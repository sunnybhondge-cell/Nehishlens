import type { KpiTilesResponse, DerivationResponse, PriorityItem, BriefingResponse } from '../api/endpoints';

// Minimal, clearly-fake fallback data — enough to keep the screen from
// blanking out if the API is unreachable in a demo. Never treated as real:
// useHydrated() only returns these when the live call failed, and the
// caller always renders isFixture -> ConnectionBanner "Showing saved data".
export const kpiTilesFixture: KpiTilesResponse = {
  tiles: [
    { label: 'Open incidents', value: '—', caption: 'saved data' },
    { label: 'Hours saved (30d)', value: '—', caption: 'saved data' },
    { label: 'Recall hit rate', value: '—', caption: 'saved data' },
    { label: 'BOD breaches', value: '—', caption: 'saved data' },
  ],
};

export const derivationFixture: DerivationResponse = {
  id: 'hours-saved',
  label: 'Hours saved',
  value: '—',
  steps: ['Live derivation unavailable — this is saved data, not a computed figure.'],
};

export const prioritiesFixture: PriorityItem[] = [];

export const briefingFixture: BriefingResponse = {
  paragraph: 'The overnight briefing could not be loaded from the API. This is saved placeholder text, not a real briefing.',
  citations: [],
};
