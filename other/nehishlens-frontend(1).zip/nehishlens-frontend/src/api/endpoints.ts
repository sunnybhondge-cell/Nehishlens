/**
 * One function per operation in openapi.yaml (35 total), grouped exactly as
 * the wiring guide groups them, so this file and the guide can be read
 * side-by-side. Response types are intentionally loose (`unknown`/partial)
 * where the guide doesn't spell out the full shape — tighten them against
 * /docs (Swagger "try it out") as you wire each screen; don't guess fields
 * that matter for a decision (confidence, retryable, etc.) without checking.
 */
import { api } from './client';

// ---------------------------------------------------------------------------
// Today · Screen 1 — the model to copy (wired first, per the guide)
// ---------------------------------------------------------------------------
export const TodayApi = {
  metricsSummary: () => api.get<KpiTilesResponse>('/metrics/summary'),
  derivation: (derivationId: string, mockState?: string) =>
    api.get<DerivationResponse>(`/derivations/${encodeURIComponent(derivationId)}`, { mockState }),
  priorities: () => api.get<PriorityItem[]>('/priorities'),
  briefing: () => api.get<BriefingResponse>('/briefing'),
};

// ---------------------------------------------------------------------------
// Incidents · Screen 2
// ---------------------------------------------------------------------------
export const IncidentsApi = {
  list: (stage?: string) => api.get<IncidentSummary[]>(`/incidents${stage ? `?stage=${encodeURIComponent(stage)}` : ''}`),
  create: (payload: ObserveIncidentPayload) => api.post<ObserveIncidentResponse>('/incidents', payload),
  detail: (incidentId: string) => api.get<IncidentDetail>(`/incidents/${encodeURIComponent(incidentId)}`),
  patchLoop: (incidentId: string, stage: string) =>
    api.patch<IncidentDetail>(`/incidents/${encodeURIComponent(incidentId)}/loop`, { stage }),
  recall: (incidentId: string) => api.get<RecallMatch>(`/incidents/${encodeURIComponent(incidentId)}/recall`),
  rejectRecall: (incidentId: string, reason?: string) =>
    api.post<void>(`/incidents/${encodeURIComponent(incidentId)}/recall/reject`, { reason }),
};

// ---------------------------------------------------------------------------
// Actions · Screen 2 (the write path — see docs/API_WIRING.md "What is left")
// ---------------------------------------------------------------------------
export const ActionsApi = {
  approvers: (lens: string, incidentId: string) =>
    api.get<Approver[]>(`/policy/approvers?lens=${encodeURIComponent(lens)}&incidentId=${encodeURIComponent(incidentId)}`),
  runbook: (resolutionId: string) => api.get<Runbook>(`/runbooks/${encodeURIComponent(resolutionId)}`),
  propose: (payload: ProposeActionPayload) => api.post<ActionRecord>('/actions', payload),
  approve: (actionId: string, payload: ApproveActionPayload) =>
    api.post<ApproveActionResponse>(`/actions/${encodeURIComponent(actionId)}/approve`, payload),
  receipt: (actionId: string) => api.get<Receipt>(`/actions/${encodeURIComponent(actionId)}/receipt`),
};

// ---------------------------------------------------------------------------
// EOD & Batch · Screen 3
// ---------------------------------------------------------------------------
export const EodApi = {
  run: (runId: string, mockState?: string) => api.get<RunTimeline>(`/runs/${encodeURIComponent(runId)}`, { mockState }),
  feedHealth: () => api.get<FeedHealth[]>('/feeds/health'),
};

// ---------------------------------------------------------------------------
// Audit & Evidence · Screen 4
// ---------------------------------------------------------------------------
export const AuditApi = {
  list: (limit?: number) => api.get<AuditEntry[]>(`/audit${limit ? `?limit=${limit}` : ''}`),
  verify: () => api.get<AuditVerifyResponse>('/audit/verify'),
  byHash: (entryHash: string) => api.get<AuditEntry>(`/audit/${encodeURIComponent(entryHash)}`),
};

// ---------------------------------------------------------------------------
// Corpus · Screen 5
// ---------------------------------------------------------------------------
export const CorpusApi = {
  metrics: () => api.get<CorpusMetrics>('/corpus/metrics'),
  resolutions: () => api.get<Resolution[]>('/resolutions'),
  // Note ids contain '#' (e.g. res#1198) — must be percent-encoded (res%231198).
  resolution: (resolutionId: string) => api.get<Resolution>(`/resolutions/${encodeURIComponent(resolutionId)}`),
  captureResolution: (payload: CaptureResolutionPayload) => api.post<Resolution>('/resolutions', payload),
  reuse: (resolutionId: string) => api.post<Resolution>(`/resolutions/${encodeURIComponent(resolutionId)}/reuse`),
  signature: (signatureId: string) => api.get<Signature>(`/signatures/${encodeURIComponent(signatureId)}`),
  signatureOccurrences: (signatureId: string) =>
    api.get<IncidentSummary[]>(`/signatures/${encodeURIComponent(signatureId)}/occurrences`),
};

// ---------------------------------------------------------------------------
// Corpus · Sources · Screen 5
// ---------------------------------------------------------------------------
export const SourcesApi = {
  citations: () => api.get<Citation[]>('/citations'),
  citation: (citationId: string) => api.get<Citation>(`/citations/${encodeURIComponent(citationId)}`),
  list: (q?: string) => api.get<SourceSummary[]>(`/sources${q ? `?q=${encodeURIComponent(q)}` : ''}`),
  // Can 403 not_granted per lens — always call through fetchAllSettled when
  // fanning this out over a list (wiring guide rule 5 / the Sources bug).
  detail: (sourceId: string) => api.get<SourceDetail>(`/sources/${encodeURIComponent(sourceId)}`),
};

// ---------------------------------------------------------------------------
// Settings · Screen 7 — fetched deliberately, not rendered (contract gap)
// ---------------------------------------------------------------------------
export const SettingsApi = {
  thresholds: () => api.get<ThresholdsResponse>('/config/thresholds'),
};

// ---------------------------------------------------------------------------
// Mock control — not tied to a screen
// ---------------------------------------------------------------------------
export const MockControlApi = {
  reset: () => api.post<void>('/_reset'),
  states: () => api.get<unknown>('/_states'),
};

// ---------------------------------------------------------------------------
// Minimal response types — expand as you wire each screen against /docs.
// Keep field names identical to the API's; do the shape adaptation (e.g.
// EOD's cumulative offsets) in the hook layer, not here (guide: "shape
// adaptation belongs in HYDRATE, not the API").
// ---------------------------------------------------------------------------
export interface KpiTile { label: string; value: string | number; caption?: string }
export interface KpiTilesResponse { tiles: KpiTile[] }
export interface DerivationResponse { id: string; label: string; value: string | number; steps: string[]; caveats?: string[] }
export interface PriorityItem { id: string; title: string; severity: string; [key: string]: unknown }
export interface BriefingResponse { paragraph: string; citations: Citation[] }

export interface IncidentSummary { id: string; title: string; stage: string; severity: string; [key: string]: unknown }
export interface IncidentDetail extends IncidentSummary {
  impact?: string;
  diagnosis?: string;
  confidence?: number;
  confidencePct?: number;
  evidence?: unknown[];
  notVerified?: string[];
  citations?: Citation[];
  loop?: { log: unknown[] };
}
export interface ObserveIncidentPayload {
  title: string; message: string; module: string; stageName: string; severity: string; branch?: string;
}
export interface ObserveIncidentResponse { incident: IncidentDetail; recognised: boolean; resolution?: Resolution; note?: string }
export interface RecallMatch { candidates: unknown[]; exactMatch?: boolean }
export interface Approver { id: string; name: string; role: string }
export interface Runbook { steps: string[]; resolutionId: string }
export interface ProposeActionPayload { incidentId: string; steps: string[]; proposerId: string; requiredApproverId: string }
export interface ApproveActionPayload { approverId: string; outcome: 'succeeded' | 'failed'; condition?: string }
export interface ActionRecord { id: string; incidentId: string; status: string; [key: string]: unknown }
export interface ApproveActionResponse { action: ActionRecord; receipt: Receipt; incidentStage: string }
export interface Receipt { id: string; chain: unknown[]; [key: string]: unknown }

export interface RunTimeline { runId: string; stages: RunStage[]; gap?: string; bodBreached?: boolean }
export interface RunStage { name: string; expectedMin: number; actualMin: number; deviation?: number }
export interface FeedHealth { source: string; heartbeatAt: string | null; silent: boolean; reason?: string }

export interface AuditEntry { hash: string; seq: number; actorKind: 'ai' | 'human'; [key: string]: unknown }
export interface AuditVerifyResponse { intact: boolean; length?: number; brokenAtSeq?: number }

export interface CorpusMetrics { resolutions: number; reuseEventsThisWeek: number; recallHitRatePct: number; notCaptured: number; addedToday: number }
export interface Resolution { id: string; related?: unknown[]; evidenceList?: unknown[]; approvedBy?: string; [key: string]: unknown }
export interface CaptureResolutionPayload { approvedBy: string; [key: string]: unknown }
export interface Signature { id: string; includedFacets: string[]; excludedFacets: string[]; occurrenceCount: number }

export interface Citation { id: string; label: string; sourceId?: string; unit?: string }
export interface SourceSummary { id: string; name: string; denied?: boolean; deniedReason?: string }
export interface SourceDetail extends SourceSummary { coverage?: string; gaps?: string[]; units?: string[] }

export interface ThresholdEntry { value: number; unit: string; tuned: boolean; note?: string }
export interface ThresholdsResponse { recallMinMatch?: ThresholdEntry; refuseBelowConfidence?: ThresholdEntry; staleSourceDays?: ThresholdEntry }
