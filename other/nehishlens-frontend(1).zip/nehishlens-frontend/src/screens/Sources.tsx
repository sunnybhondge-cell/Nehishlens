import { useEffect, useState } from 'react';
import { SourcesApi, type SourceDetail } from '../api/endpoints';
import { useHydrated } from '../hooks/useHydrated';
import { fetchAllSettled } from '../api/client';
import { ApiErrorBanner } from '../components/ApiErrorBanner';

/**
 * Wiring guide rule 5, worked example: fan out per-source detail with
 * Promise.allSettled, not Promise.all — a single 403 (a lens-denied
 * source, e.g. src-sanctions-ref) must not take the whole screen down to
 * fixtures. Denied sources are kept in the list, flagged, with the
 * server's own reason attached.
 */
export function Sources() {
  const list = useHydrated(['sources'], () => SourcesApi.list(), []);
  const [details, setDetails] = useState<Record<string, SourceDetail>>({});

  useEffect(() => {
    if (!list.data || list.data.length === 0) return;
    let cancelled = false;

    fetchAllSettled(list.data.map((s) => SourcesApi.detail(s.id))).then((results) => {
      if (cancelled) return;
      const byId: Record<string, SourceDetail> = {};
      results.forEach((res, i) => {
        const source = list.data![i];
        byId[source.id] =
          res.status === 'fulfilled'
            ? res.value
            : { ...source, denied: true, deniedReason: res.reason.message };
      });
      setDetails(byId);
    });

    return () => {
      cancelled = true;
    };
  }, [list.data]);

  return (
    <div className="panel">
      <h2>Corpus · Sources</h2>
      {list.isFixture && <p className="fixture-note">Showing saved data — sources.</p>}
      {list.error && !list.isFixture && <ApiErrorBanner error={list.error} what="the source list" />}
      <ul>
        {(list.data ?? []).map((s) => {
          const detail = details[s.id];
          return (
            <li key={s.id}>
              <strong>{s.name}</strong>
              {detail?.denied && (
                <span className="fixture-note"> — denied: {detail.deniedReason}</span>
              )}
            </li>
          );
        })}
      </ul>
    </div>
  );
}
