import { EodApi } from '../api/endpoints';
import { useHydrated } from '../hooks/useHydrated';
import { ApiErrorBanner } from '../components/ApiErrorBanner';

const DEMO_RUN_ID = 'run-current'; // TODO: replace with the real run id source (route param / today's run).

export function Eod() {
  const run = useHydrated(['run', DEMO_RUN_ID], () => EodApi.run(DEMO_RUN_ID), undefined);

  return (
    <div className="panel">
      <h2>EOD & Batch</h2>
      {run.isFixture && <p className="fixture-note">Showing saved data — run timeline.</p>}
      {run.error && !run.isFixture && <ApiErrorBanner error={run.error} what="the run timeline" />}
      {run.data?.gap && <p className="fixture-note">Partial run — {run.data.gap}</p>}
      <ul>
        {(run.data?.stages ?? []).map((s) => (
          <li key={s.name}>
            {s.name}: expected {s.expectedMin}min, actual {s.actualMin}min
            {typeof s.deviation === 'number' && ` (deviation ${s.deviation}min)`}
          </li>
        ))}
      </ul>

      <div className="panel">
        <h3>Feed health</h3>
        <p className="fixture-note">
          Not wired yet (GET /feeds/health) — see docs/API_WIRING.md, "What is left" #3. A silent source must not
          look the same as a quiet night once this is wired.
        </p>
      </div>
    </div>
  );
}
