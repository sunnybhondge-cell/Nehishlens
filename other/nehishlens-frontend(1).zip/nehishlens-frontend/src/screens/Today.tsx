import { TodayApi } from '../api/endpoints';
import { useHydrated } from '../hooks/useHydrated';
import { ApiErrorBanner } from '../components/ApiErrorBanner';
import { kpiTilesFixture, derivationFixture, prioritiesFixture, briefingFixture } from '../fixtures/today';

/**
 * Screen 1 · Today. Per the wiring guide this is "the model to copy" — the
 * four fragments below (KPI tiles, derivation, priorities, briefing) were
 * wired first in the reference implementation. Every other screen's hook
 * follows this same shape: useHydrated(key, fetcher, fixture).
 *
 * "Needs a decision" stays static/fixture-only on purpose — the guide notes
 * it has to become a renderer (GET /incidents?stage=) before it can be
 * wired, and that conversion is tracked as future work, not done here.
 */
export function Today() {
  const kpis = useHydrated(['metrics-summary'], TodayApi.metricsSummary, kpiTilesFixture);
  const derivation = useHydrated(['derivation', 'hours-saved'], () => TodayApi.derivation('hours-saved'), derivationFixture);
  const priorities = useHydrated(['priorities'], TodayApi.priorities, prioritiesFixture);
  const briefing = useHydrated(['briefing'], TodayApi.briefing, briefingFixture);

  return (
    <div className="screen-today">
      <section className="kpi-top-row">
        <div className="kpi-row-head">
          <h2>Today</h2>
        </div>
        {kpis.isFixture && <p className="fixture-note">Showing saved data — KPI tiles.</p>}
        {kpis.error && !kpis.isFixture && <ApiErrorBanner error={kpis.error} what="the KPI tiles" />}
        <div className="tiles">
          {(kpis.data?.tiles ?? []).map((tile) => (
            <div className="tile" key={tile.label}>
              <div className="t-label">{tile.label}</div>
              <div className="t-metric">{kpis.isLoading ? '…' : tile.value}</div>
              {tile.caption && <div className="t-caption">{tile.caption}</div>}
            </div>
          ))}
        </div>
      </section>

      <div className="panel">
        <h3>Baseline → derivation</h3>
        {derivation.isFixture && <p className="fixture-note">Showing saved data — derivation.</p>}
        {derivation.error && !derivation.isFixture && <ApiErrorBanner error={derivation.error} what="the derivation" />}
        {derivation.data && (
          <>
            <p className="t-metric">{derivation.data.value}</p>
            <ol>
              {derivation.data.steps.map((s, i) => (
                <li key={i}>{s}</li>
              ))}
            </ol>
          </>
        )}
      </div>

      <div className="panel">
        <h3 id="priorityTitle">What needs attention first</h3>
        {priorities.isFixture && <p className="fixture-note">Showing saved data — priorities.</p>}
        {priorities.error && !priorities.isFixture && <ApiErrorBanner error={priorities.error} what="priorities" />}
        <ul>
          {(priorities.data ?? []).map((p) => (
            <li key={p.id}>
              <strong>{p.title}</strong> <span className="chip">{p.severity}</span>
            </li>
          ))}
          {priorities.data?.length === 0 && !priorities.isLoading && <li>Nothing needs attention right now.</li>}
        </ul>
      </div>

      <div className="panel">
        <h3>Overnight briefing</h3>
        {briefing.isFixture && <p className="fixture-note">Showing saved data — briefing.</p>}
        {briefing.error && !briefing.isFixture && <ApiErrorBanner error={briefing.error} what="the briefing" />}
        {briefing.data && <p>{briefing.data.paragraph}</p>}
      </div>

      <div className="panel">
        <h3>Needs a decision</h3>
        <p className="fixture-note">
          Still static markup per the wiring guide — this list is not a renderer yet, so it is not wired. See
          docs/API_WIRING.md, Screen 1.
        </p>
      </div>
    </div>
  );
}
