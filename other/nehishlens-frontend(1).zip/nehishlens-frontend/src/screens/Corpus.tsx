import { CorpusApi } from '../api/endpoints';
import { useHydrated } from '../hooks/useHydrated';
import { ApiErrorBanner } from '../components/ApiErrorBanner';

export function Corpus() {
  const resolutions = useHydrated(['resolutions'], CorpusApi.resolutions, []);

  return (
    <div className="panel">
      <h2>Corpus</h2>
      {resolutions.isFixture && <p className="fixture-note">Showing saved data — resolutions.</p>}
      {resolutions.error && !resolutions.isFixture && <ApiErrorBanner error={resolutions.error} what="the corpus" />}
      <table className="tbl">
        <thead>
          <tr>
            <th>ID</th>
            <th>Approved by</th>
          </tr>
        </thead>
        <tbody>
          {(resolutions.data ?? []).map((r) => (
            <tr key={r.id}>
              <td className="mono">{r.id}</td>
              <td>{r.approvedBy ?? '—'}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <div className="panel">
        <h3>Corpus tiles, signatures, capture &amp; reuse</h3>
        <p className="fixture-note">
          Not wired yet — GET /corpus/metrics, GET /signatures/&#123;id&#125;, POST /resolutions, POST
          /resolutions/&#123;id&#125;/reuse. Mechanical per the guide ("What is left" #4) — the shapes already
          match; follow the useHydrated pattern above for each.
        </p>
      </div>
    </div>
  );
}
