import { useEffect } from 'react';
import { SettingsApi } from '../api/endpoints';

const SCREEN_THRESHOLDS = [
  { label: 'Strong match', value: '0.85' },
  { label: 'Weak match floor', value: '0.60' },
  { label: 'Ambiguity delta', value: '0.05' },
  { label: 'Minimum history', value: '14 days' },
  { label: 'Ungrounded below', value: '0.40' },
  { label: 'Coverage floor', value: '0.50' },
  { label: 'Uncertainty expiry', value: '4 hours' },
];

/**
 * Deliberately not rendered from the API — see wiring guide, Screen 7.
 * GET /config/thresholds only returns 3 of the 7 parameters this screen
 * documents, and they don't map cleanly onto each other (only
 * "Strong match" ↔ recallMinMatch is a clean pair). Rendering the 3 would
 * delete 4 rows of documented product behaviour. The fetch below exists so
 * the app proves it CAN reach the endpoint and so THRESHOLDS_LIVE isn't
 * dead code waiting to be forgotten — nothing reads its result yet. Do not
 * wire this further until the backend/product rules on the gap (see
 * docs/API_WIRING.md, "What is left" #5, and "For the backend team").
 */
export function Settings() {
  useEffect(() => {
    SettingsApi.thresholds().catch(() => {
      // Intentionally ignored — this call exists to prove reachability, not to render.
    });
  }, []);

  return (
    <div className="panel">
      <h2>Settings</h2>
      <p className="fixture-note">
        These 7 thresholds are documented product behaviour, shown as configured. Only 1 of them
        (recallMinMatch) has a live API equivalent today — see docs/API_WIRING.md for the full gap. PATCH is
        not implemented on the mock; this screen is read-only either way.
      </p>
      <table className="tbl">
        <tbody>
          {SCREEN_THRESHOLDS.map((t) => (
            <tr key={t.label}>
              <td>{t.label}</td>
              <td className="mono">{t.value}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
