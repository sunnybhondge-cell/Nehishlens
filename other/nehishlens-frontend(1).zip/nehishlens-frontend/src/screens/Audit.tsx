import { AuditApi } from '../api/endpoints';
import { useHydrated } from '../hooks/useHydrated';
import { ApiErrorBanner } from '../components/ApiErrorBanner';

export function Audit() {
  const trail = useHydrated(['audit'], () => AuditApi.list(50), []);

  return (
    <div className="panel">
      <h2>Audit & Evidence</h2>
      {trail.isFixture && <p className="fixture-note">Showing saved data — audit trail.</p>}
      {trail.error && !trail.isFixture && <ApiErrorBanner error={trail.error} what="the audit trail" />}
      <table className="tbl">
        <thead>
          <tr>
            <th>Seq</th>
            <th>Hash</th>
            <th>Actor</th>
          </tr>
        </thead>
        <tbody>
          {(trail.data ?? []).map((e) => (
            <tr key={e.hash}>
              <td>{e.seq}</td>
              <td className="mono">{e.hash}</td>
              <td>{e.actorKind}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <p className="fixture-note">
        "Chain intact" is still asserted in markup, not wired to GET /audit/verify — see docs/API_WIRING.md, "What is
        left" #2. This is the cheapest credibility the screen can buy once it is.
      </p>
    </div>
  );
}
