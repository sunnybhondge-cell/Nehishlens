import { Link, useParams } from 'react-router-dom';
import { IncidentsApi } from '../api/endpoints';
import { useHydrated } from '../hooks/useHydrated';
import { ApiErrorBanner } from '../components/ApiErrorBanner';

/**
 * Screen 2 · Incidents. List is wired live (matches the reference build).
 * Detail reads the same hydrated data but the three calls that make the
 * action surface real — /recall, /policy/approvers, /runbooks/{id} — plus
 * the write path (POST /actions, POST /actions/{id}/approve) are NOT wired
 * here, exactly as documented in the guide's "what is left" §1. Wiring
 * them means repeating this file's pattern for each call and gating the
 * "Apply fix" button on /policy/approvers resolving first (guide, §6.4
 * rule 2) — see docs/API_WIRING.md for the full checklist.
 */
export function IncidentsList() {
  const incidents = useHydrated(['incidents'], () => IncidentsApi.list(), []);

  return (
    <div className="panel">
      <h2>Incidents</h2>
      {incidents.isFixture && <p className="fixture-note">Showing saved data — incident list.</p>}
      {incidents.error && !incidents.isFixture && <ApiErrorBanner error={incidents.error} what="the incident list" />}
      <p>All · {incidents.data?.length ?? 0}</p>
      <ul>
        {(incidents.data ?? []).map((inc) => (
          <li key={inc.id}>
            <Link to={`/incidents/${inc.id}`}>
              <strong>{inc.title}</strong> — {inc.stage} · {inc.severity}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}

export function IncidentDetail() {
  const { id } = useParams<{ id: string }>();
  const incident = useHydrated(['incident', id], () => IncidentsApi.detail(id!), undefined);

  if (!id) return null;

  return (
    <div className="panel">
      <Link to="/incidents">&larr; Incidents</Link>
      <h2>{incident.data?.title ?? id}</h2>
      {incident.error && <ApiErrorBanner error={incident.error} what="this incident" />}
      {incident.data && (
        <>
          <p>{incident.data.impact}</p>
          <p>{incident.data.diagnosis}</p>
          {typeof incident.data.confidencePct === 'number' && <p>Confidence: {incident.data.confidencePct}%</p>}
          {incident.data.notVerified && incident.data.notVerified.length > 0 && (
            <div className="fixture-note">
              Not verified: {incident.data.notVerified.join('; ')}
            </div>
          )}
        </>
      )}
      <div className="panel">
        <h3>Action</h3>
        <p className="fixture-note">
          Not wired yet — requires GET /policy/approvers to resolve before the button is enabled (§6.4 rule 2). See
          docs/API_WIRING.md, "What is left" #1.
        </p>
      </div>
    </div>
  );
}
