/**
 * Screen 6 · DB Console. "Not in the mock." (wiring guide) The permission
 * gate is real and client-side today — leave it that way until the mock
 * covers this screen.
 */
export function DbConsole() {
  return (
    <div className="panel">
      <h2>DB Console</h2>
      <p className="fixture-note">
        Not backed by the mock API — see docs/API_WIRING.md, Screen 6. This screen is left as-is (fixtures,
        client-side permission gate) on purpose.
      </p>
    </div>
  );
}
