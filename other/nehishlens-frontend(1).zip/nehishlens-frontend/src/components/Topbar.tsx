import { useLens } from '../context/LensContext';
import { ConnectionBanner } from './ConnectionBanner';
import type { Lens } from '../api/config';

const LENSES: Lens[] = ['ops', 'eng', 'assure', 'exec'];

export function Topbar({ online }: { online: boolean | null }) {
  const { lens, setActiveLens } = useLens();

  return (
    <header className="topbar">
      <strong style={{ marginRight: 12 }}>NehishLens</strong>
      <ConnectionBanner online={online} />
      <div className="chip" style={{ marginLeft: 'auto', display: 'flex', gap: 4 }}>
        {LENSES.map((l) => (
          <button
            key={l}
            onClick={() => setActiveLens(l)}
            aria-pressed={lens === l}
            style={{
              background: lens === l ? 'var(--lens)' : 'transparent',
              color: lens === l ? '#0B0E12' : 'inherit',
              border: 'none',
              borderRadius: 999,
              padding: '2px 10px',
              fontSize: 11,
              textTransform: 'uppercase',
              letterSpacing: '.05em',
              fontWeight: 700,
            }}
          >
            {l}
          </button>
        ))}
      </div>
    </header>
  );
}
