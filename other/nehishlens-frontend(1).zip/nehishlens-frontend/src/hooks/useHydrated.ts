import { useQuery } from '@tanstack/react-query';
import { apiConfig } from '../api/config';
import { ApiError } from '../api/client';

export interface HydratedResult<T> {
  data: T | undefined;
  isLoading: boolean;
  /** true when `data` came from the bundled fixture, not the live API. */
  isFixture: boolean;
  error: ApiError | null;
  refetch: () => void;
}

/**
 * React equivalent of HYDRATE.* in the reference implementation: try the
 * live endpoint; if it fails and fixture fallback is allowed, fall back to
 * the given fixture — but always report `isFixture` so the UI can show the
 * "showing saved data" banner (wiring guide rule 2 — never show fixtures as
 * if they were live).
 *
 * This does NOT swallow the error silently: `error` is still populated so
 * the caller can render the server's own message (rule 1) alongside, or
 * instead of, the fixture, depending on the screen's needs.
 */
export function useHydrated<T>(
  queryKey: unknown[],
  fetcher: () => Promise<T>,
  fixture: T | undefined,
): HydratedResult<T> {
  const query = useQuery<T, ApiError>({
    queryKey,
    queryFn: fetcher,
  });

  const useFixture = !!query.isError && apiConfig.allowFixtureFallback && fixture !== undefined;

  return {
    data: useFixture ? fixture : query.data,
    isLoading: query.isLoading,
    isFixture: useFixture,
    error: (query.error as ApiError | null) ?? null,
    refetch: () => query.refetch(),
  };
}
