import { HashRouter, Routes, Route, Navigate, NavLink } from 'react-router-dom';
import { Topbar } from './components/Topbar';
import { Today } from './screens/Today';
import { IncidentsList, IncidentDetail } from './screens/Incidents';
import { Eod } from './screens/Eod';
import { Audit } from './screens/Audit';
import { Corpus } from './screens/Corpus';
import { Sources } from './screens/Sources';
import { Settings } from './screens/Settings';
import { DbConsole } from './screens/DbConsole';
import { useConnectionProbe } from './hooks/useConnection';
import { LensProvider } from './context/LensContext';

const NAV = [
  { to: '/today', label: 'Today' },
  { to: '/incidents', label: 'Incidents' },
  { to: '/eod', label: 'EOD & Batch' },
  { to: '/audit', label: 'Audit' },
  { to: '/corpus', label: 'Corpus' },
  { to: '/sources', label: 'Sources' },
  { to: '/settings', label: 'Settings' },
  { to: '/db-console', label: 'DB Console' },
];

export default function App() {
  // boot(): probe once, then render — see wiring guide, "four bugs the wiring surfaced".
  const { online } = useConnectionProbe();

  return (
    <LensProvider>
      <HashRouter>
        <div className="app-shell">
          <Topbar online={online} />
          <div style={{ display: 'flex' }}>
            <nav className="side-nav">
              {NAV.map((n) => (
                <NavLink key={n.to} to={n.to} className={({ isActive }) => (isActive ? 'active' : '')}>
                  {n.label}
                </NavLink>
              ))}
            </nav>
            <main style={{ flex: 1, padding: 16 }}>
              <Routes>
                <Route path="/" element={<Navigate to="/today" replace />} />
                <Route path="/today" element={<Today />} />
                <Route path="/incidents" element={<IncidentsList />} />
                <Route path="/incidents/:id" element={<IncidentDetail />} />
                <Route path="/eod" element={<Eod />} />
                <Route path="/audit" element={<Audit />} />
                <Route path="/corpus" element={<Corpus />} />
                <Route path="/sources" element={<Sources />} />
                <Route path="/settings" element={<Settings />} />
                <Route path="/db-console" element={<DbConsole />} />
              </Routes>
            </main>
          </div>
        </div>
      </HashRouter>
    </LensProvider>
  );
}
