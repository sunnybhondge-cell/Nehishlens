# Code walkthrough — for a new developer on this project

This assumes you know basic JavaScript but nothing about React, Vite, or
this codebase specifically. It's meant to be read once, top to bottom,
before you touch any code. Everything else in `docs/` assumes you've read
this.

## 1. The three technologies, in one paragraph each

**React** — a library for building UIs out of small, reusable pieces
called **components**. A component is just a function that returns some
markup (written in a JSX syntax that looks like HTML but is actually
JavaScript). React re-runs a component's function and updates the real DOM
whenever the component's **state** changes. You'll see two hooks
constantly: `useState` (a variable that, when changed, triggers a
re-render) and `useEffect` (run some code when the component mounts, or
when specific values change).

**TypeScript** — JavaScript with type annotations. `function add(a: number, b: number): number` means the compiler will yell at you if you pass a string. Every `.ts`/`.tsx` file here is TypeScript. It doesn't change how the app runs — it catches mistakes before you run it. Run `npm run build` (which runs `tsc -b` first) to see every type error in the project at once.

**Vite** — the tool that runs the dev server (`npm run dev`) and bundles everything into static files for deployment (`npm run build`). You don't need to configure it; `vite.config.ts` is already set up. The one Vite-specific thing to know: env variables must start with `VITE_` to be readable in the browser (see `docs/ENVIRONMENT.md`).

## 2. Folder structure, and what belongs where

```
src/
  api/           - talking to the backend. Nothing else in the app calls fetch() directly.
    config.ts       - reads .env values. The ONLY file that touches import.meta.env.
    client.ts        - the actual fetch wrapper: adds headers, parses errors, tracks online/offline.
    endpoints.ts     - one small function per API endpoint, e.g. TodayApi.metricsSummary().

  hooks/          - reusable logic that isn't UI. A "hook" is just a function
                    whose name starts with `use` and that's allowed to call
                    other hooks (useState, useEffect, etc.) inside it.
    useHydrated.ts   - "fetch this, and if it fails, fall back to this fixture."
    useConnection.ts - "check once, on startup, whether the API is reachable."

  context/        - state shared across many components without passing
                    props down manually. We only have one: which "lens"
                    (ops/eng/assure/exec) is currently selected.

  screens/        - one file per app screen (Today.tsx, Incidents.tsx, ...).
                    A screen is just a component, rendered by a route in App.tsx.

  components/     - small reusable pieces used by more than one screen
                    (the top bar, the error banner, the connection chip).

  fixtures/       - hard-coded placeholder data, used ONLY when the live
                    API call fails and VITE_ALLOW_FIXTURE_FALLBACK=true.

  styles/legacy.css - CSS extracted from the original HTML prototype, so
                    class names like .panel, .tile, .chip look the same.
  index.css         - a few additional styles we needed that weren't in
                    the original file (the side nav, the API banners).

  App.tsx         - defines the routes (which URL shows which screen) and
                    the page layout (top bar + side nav + main content).
  main.tsx        - the actual entry point. Sets up React Query and renders
                    <App /> into the page. You'll rarely need to touch this.
```

## 3. How a screen actually gets its data — traced end to end

This is the single most important thing to understand. Every wired screen
follows exactly this path. We'll trace the KPI tiles on the Today screen.

**Step 1 — the screen asks a hook for data.**
`src/screens/Today.tsx`:
```tsx
const kpis = useHydrated(['metrics-summary'], TodayApi.metricsSummary, kpiTilesFixture);
```
Three arguments: a unique cache key, the function to call to get real data,
and the fixture to fall back to if that call fails.

**Step 2 — the hook calls the endpoint function.**
`src/hooks/useHydrated.ts` uses React Query's `useQuery` to call
`TodayApi.metricsSummary` for you (React Query also handles caching,
loading state, and re-fetching — you don't write any of that by hand).

**Step 3 — the endpoint function calls the shared client.**
`src/api/endpoints.ts`:
```ts
export const TodayApi = {
  metricsSummary: () => api.get<KpiTilesResponse>('/metrics/summary'),
  ...
};
```
`api.get` comes from `src/api/client.ts` — it's the one function in the
whole app that actually calls `fetch()`.

**Step 4 — the client builds the real request.**
`src/api/client.ts` reads `apiConfig.baseUrl` (from `.env`, via
`src/api/config.ts`) and builds the full URL:
`https://mock-api-nehishlens.aminobots.com/api/v1/metrics/summary`, adds
the `X-Lens` header, sends it, and either returns the parsed JSON or throws
an `ApiError` with the server's own `{code, message, retryable}`.

**Step 5 — the result flows back up.**
If it succeeded: `kpis.data` now holds `{tiles: [...]}`, `kpis.isFixture`
is `false`.
If it failed: `useHydrated` catches that, and (if fallback is allowed)
returns the fixture instead, with `kpis.isFixture = true` — the screen
uses that flag to show a "showing saved data" note instead of pretending
the fixture is real.

**Step 6 — the screen renders it.**
```tsx
{(kpis.data?.tiles ?? []).map((tile) => (
  <div className="tile" key={tile.label}>...</div>
))}
```
That's it — no manual loading spinners, no manual try/catch in the
component. All of that lives in the hook, once, and every screen reuses it.

### Diagram

```
Today.tsx
   │  useHydrated(['metrics-summary'], TodayApi.metricsSummary, fixture)
   ▼
useHydrated.ts ──uses──▶ React Query (caching, loading state, retries)
   │  calls
   ▼
endpoints.ts:  TodayApi.metricsSummary() = api.get('/metrics/summary')
   │  calls
   ▼
client.ts:  api.get()  ──▶  fetch(`${VITE_API_BASE_URL}/metrics/summary`, { headers: { 'X-Lens': ... } })
   │
   ▼
Mock API (https://mock-api-nehishlens.aminobots.com)
   │
   ▼  response flows back up through the same chain
Today.tsx renders kpis.data / kpis.isFixture / kpis.error
```

## 4. How routing works

`src/App.tsx` uses `react-router-dom`'s `HashRouter` — that's why URLs
look like `http://localhost:5173/#/incidents` rather than
`http://localhost:5173/incidents`. This matches the original prototype's
URL scheme (see the wiring guide) and needs no server configuration.

```tsx
<Routes>
  <Route path="/today" element={<Today />} />
  <Route path="/incidents" element={<IncidentsList />} />
  <Route path="/incidents/:id" element={<IncidentDetail />} />
  ...
</Routes>
```

`:id` is a URL parameter — inside `IncidentDetail`, `useParams<{ id: string }>()` reads it back out. Try it: click an incident on the Incidents screen and watch the URL change to `#/incidents/INC-2261`.

## 5. A worked example: adding a brand new wired fragment

Say you're asked to wire "feed health" on the EOD screen (currently a
TODO — see `docs/API_WIRING.md`). Here's the exact recipe, following the
Today screen as the template:

1. **Check the response shape.** Open https://mock-api-nehishlens.aminobots.com/docs, find `GET /feeds/health`, click "Try it out", run it, look at the JSON that comes back.

2. **Confirm/adjust the type** in `src/api/endpoints.ts` — there's already a stub:
   ```ts
   export interface FeedHealth { source: string; heartbeatAt: string | null; silent: boolean; reason?: string }
   ```
   Adjust field names to match what you actually saw in step 1.

3. **The endpoint function already exists too:**
   ```ts
   export const EodApi = {
     ...
     feedHealth: () => api.get<FeedHealth[]>('/feeds/health'),
   };
   ```

4. **Add a fixture** (a small array of fake `FeedHealth` objects) — put it in `src/fixtures/eod.ts` (new file), following the shape of `src/fixtures/today.ts`.

5. **Call `useHydrated` in the screen**, `src/screens/Eod.tsx`:
   ```tsx
   const feeds = useHydrated(['feeds-health'], EodApi.feedHealth, feedHealthFixture);
   ```

6. **Render it**, same pattern as everywhere else:
   ```tsx
   {feeds.isFixture && <p className="fixture-note">Showing saved data — feed health.</p>}
   {feeds.error && !feeds.isFixture && <ApiErrorBanner error={feeds.error} what="feed health" />}
   <ul>
     {(feeds.data ?? []).map((f) => (
       <li key={f.source}>{f.source}: {f.silent ? `silent — ${f.reason}` : 'healthy'}</li>
     ))}
   </ul>
   ```

7. **Run it.** `npm run dev`, open the EOD screen, check the Network tab — you should see the real request in the browser dev tools, and `[api] GET /feeds/health -> 200 ...` in the console (because `VITE_DEBUG_API_LOGGING=true` by default).

8. **Update `docs/API_WIRING.md`** to move feed health from "still on fixtures" to "reads live" — keep that file accurate as you go.

That's the whole workflow — every remaining TODO in the codebase (see
`docs/API_WIRING.md`, "What's left") follows this same eight-step recipe.

## 6. Glossary — terms you'll hit in this codebase

| Term | Meaning here |
|---|---|
| **Hook** | A function starting with `use` that can call other hooks. `useHydrated`, `useState`, `useQuery` are all hooks. |
| **Component** | A function that returns JSX. `Today`, `Topbar`, `ApiErrorBanner` are all components. |
| **Props** | Arguments passed into a component, e.g. `<ApiErrorBanner error={...} what="..." />`. |
| **State** | Data that, when changed, causes a re-render. Managed with `useState` or (here) React Query. |
| **React Query** | The library (`@tanstack/react-query`) that handles fetching, caching, and re-fetching for us. `useHydrated` is built on top of its `useQuery`. |
| **Fixture** | Hard-coded fake data in `src/fixtures/`, shown only when the live API call fails. |
| **Lens** | The role/permission context sent as `X-Lens` on every request (`ops`, `eng`, `assure`, `exec`) — server decides what each lens can see. |
| **`.env` file** | Where all environment-specific config (API URLs, etc.) lives — see `docs/ENVIRONMENT.md`. |

## 7. Where to go next

- `docs/API_WIRING.md` — what's wired vs. still to do, screen by screen.
- `docs/ENVIRONMENT.md` — every configurable value and how to change it.
- `docs/VSCODE_SETUP.md` — running, debugging, and testing this in VS Code.
- `reference/NehishLensAPIWiringGuide.docx` — the client's original guide this whole app is built against. Worth reading once; this codebase follows its five rules and its screen-by-screen structure deliberately.
