# API wiring status

This mirrors the structure of `NehishLensAPIWiringGuide.docx` exactly, so
the two can be read side by side. "Live" means a screen in this codebase
calls the real endpoint via `useHydrated()`; "scaffolded" means the
screen/hook exists with the right shape and a `TODO` comment citing the
guide section, but doesn't call the endpoint yet.

| Screen | Reads live | Still on fixtures / scaffolded |
|---|---|---|
| Today | KPI tiles, derivation, priorities, briefing (`src/screens/Today.tsx`) | *Needs a decision* list — static per the guide; needs `GET /incidents?stage=` and a renderer first |
| Incidents | List (`src/screens/Incidents.tsx` → `IncidentsList`) | Detail's action surface: `/recall`, `/policy/approvers`, `/runbooks/{id}`; the write path (`POST /actions`, `POST /actions/{id}/approve`) |
| EOD & Batch | Run timeline (`src/screens/Eod.tsx`) | Feed health (`GET /feeds/health`) |
| Audit | Trail (`src/screens/Audit.tsx`) | `GET /audit/verify` — "chain intact" still asserted in markup |
| Corpus | Resolutions table (`src/screens/Corpus.tsx`) | Corpus tiles, signatures, capture (`POST /resolutions`), reuse (`POST /resolutions/{id}/reuse`) |
| Corpus · Sources | List + per-source detail, denials included (`src/screens/Sources.tsx`) | — (done) |
| Settings | `GET /config/thresholds` fetched, deliberately not rendered (`src/screens/Settings.tsx`) | Rendering blocked on the contract gap below, not on effort |
| DB Console | — | Not in the mock; left on fixtures (`src/screens/DbConsole.tsx`) |

## The pattern used everywhere

Every wired fragment follows the same three lines:

```ts
const kpis = useHydrated(['metrics-summary'], TodayApi.metricsSummary, kpiTilesFixture);
// kpis.data, kpis.isLoading, kpis.isFixture, kpis.error
```

`useHydrated` (`src/hooks/useHydrated.ts`) is the React equivalent of the
reference implementation's `HYDRATE` layer: it calls the live endpoint via
React Query, and only falls back to the given fixture if the call fails —
never silently, always with `isFixture: true` so the screen can render the
"showing saved data" banner (guide rule 2).

To wire a new fragment: write the fixture, write the endpoint call in
`src/api/endpoints.ts` if it isn't there yet, call `useHydrated`, render
`data`/`isFixture`/`error`. That's the whole recipe — see `Today.tsx` for
the fullest worked example, or `Sources.tsx` for the `Promise.allSettled`
fan-out variant (rule 5).

## Five rules from the guide, and where they live in code

1. **Render the server's message, never your own apology.** → `ApiErrorBanner` (`src/components/ApiErrorBanner.tsx`) renders `error.message` verbatim.
2. **Never show fixtures as if they were live.** → `useHydrated().isFixture`, surfaced by every screen; `ConnectionBanner` (`src/components/ConnectionBanner.tsx`) shows the top-bar state.
3. **The lens travels with every request.** → `X-Lens` header set in `src/api/client.ts`, controlled by `LensContext` (`src/context/LensContext.tsx`) and the switcher in `Topbar.tsx`. The client never hides a control based on lens — it renders whatever the server returns, including a 403.
4. **One owner per fragment.** → each screen's `useHydrated` call is the only thing that writes to that piece of state; React Query's cache keying (`['metrics-summary']`, `['incident', id]`, etc.) keeps fragments from overwriting each other.
5. **A refusal is data, not a failure.** → `fetchAllSettled()` (`src/api/client.ts`), used in `Sources.tsx` for the per-source detail fan-out — a single 403 (e.g. `src-sanctions-ref` denied to Operations) is kept as a flagged, denied entry rather than taking the whole screen down.

## Four bugs the guide calls out — and how this codebase avoids them by construction

- *`applyRoleChrome()` unconditionally re-rendering fixtures over live data* — doesn't apply here: there's no chrome-repaint step. React re-renders from whatever `useHydrated` currently holds; nothing separately calls a fixture renderer afterward.
- *Lens switch double-rendering (`setHash()` + `render()`)* — doesn't apply: `LensContext.setActiveLens` updates state once; React Query re-fetches once per changed query key, not per navigation event.
- *No connection probe before first paint* — ported directly: `useConnectionProbe()` (`src/hooks/useConnection.ts`), called once from `App.tsx`, mirrors `boot()`.
- *Sources hydrated with `Promise.all`, one 403 losing the whole screen* — the fix (rule 5) is the default here, not a patch: `Sources.tsx` uses `fetchAllSettled` from the start.

## Contract gaps (for the backend team, per the guide)

- **Settings**: the screen documents 7 thresholds; `/config/thresholds` exposes 3, and only `recallMinMatch` ↔ "Strong match" is a clean pair. `Settings.tsx` fetches the endpoint (so the call path is exercised and doesn't rot) but intentionally does not render it — rendering 3 of 7 would delete documented product behaviour. Held open until the backend/product rules on it.
- **Audit "Method" column**: the API has no maker-checker/fast-path field, only `actorKind: ai | human`, a different axis. `Audit.tsx` renders `actorKind` rather than inventing the old column.

## What's left (matches the guide's own priority order)

1. **The incident action flow** — `/recall`, `/policy/approvers`, `/runbooks/{id}`, then `POST /actions` and approve. Gate "Apply fix" on `/policy/approvers` resolving first (guide §6.4 rule 2). Biggest piece; proves the loop end-to-end.
2. **`/audit/verify`** — one call, replaces the "chain intact" markup assertion with a server fact.
3. **Today's decision list** and **feed health** — both blocked only on becoming renderers/hooks, same pattern as everything else here.
4. **Corpus tiles, signatures, capture, reuse** — `/corpus/metrics`, `/signatures/{id}`, `POST /resolutions`, `POST /{id}/reuse`. Mechanical; shapes already match per the guide.
5. **Settings** — blocked on the threshold ruling above, not effort.
6. **DB Console, evidence pack builder** — leave until the mock covers them.

Do 1 first — same recommendation as the guide: "the loop is demonstrable the moment it lands."
