# NehishLens — frontend

React + TypeScript + Vite port of the provided prototype
(`nehishlens-v8.html`), wired against the NehishLens mock API described in
`NehishLensAPIWiringGuide.docx`.

- Mock API docs (Swagger, try-it-out): https://mock-api-nehishlens.aminobots.com/docs
- Endpoint browser by screen: https://mock-api-nehishlens.aminobots.com/api-console
- Postman collection: https://mock-api-nehishlens.aminobots.com/collection.json

## Quick start

```bash
npm install
cp .env.example .env.development   # already provided with working defaults — edit if your API URL differs
npm run dev
```

Open http://localhost:5173. The app boots by probing `/health` once
(see `src/hooks/useConnection.ts`), then renders — if the API is
unreachable, every screen falls back to fixtures and says so in the top bar
rather than showing saved data as if it were live.

## Where things live

| Concern | File |
|---|---|
| API base URL / all environment config | `.env.example`, `src/api/config.ts` — **this is the only place API details are read from** |
| HTTP client (errors, lens header, connection state) | `src/api/client.ts` |
| Typed calls for all 35 endpoints | `src/api/endpoints.ts` |
| "HYDRATE" pattern (live-data-with-honest-fixture-fallback) | `src/hooks/useHydrated.ts` |
| Screens | `src/screens/*.tsx` |
| Ported design system (extracted verbatim from the provided HTML) | `src/styles/legacy.css` |
| Routing (hash-based, keeps old `#/today` deep links alive) | `src/App.tsx` |

Full mapping of guide → implementation, screen by screen: **[docs/API_WIRING.md](docs/API_WIRING.md)**.

## Documentation

- **[docs/ENVIRONMENT.md](docs/ENVIRONMENT.md)** — every env var, how to point the app at a different API (staging, local mock, production), how to force a mock state for testing.
- **[docs/API_WIRING.md](docs/API_WIRING.md)** — what's wired live vs. still on fixtures, per screen, and what's left — mirrors the structure of the client's own wiring guide.
- **[docs/VSCODE_SETUP.md](docs/VSCODE_SETUP.md)** — opening, running, and debugging this project in VS Code; recommended extensions; using the REST Client to hit the mock API directly from the editor.

## Scripts

```bash
npm run dev          # start the Vite dev server
npm run build         # typecheck + production build to dist/
npm run preview       # preview the production build locally
npm run check-api     # Node port of check-api.sh — verifies the mock (see docs/API_WIRING.md)
npm run lint          # oxlint
```

## Verifying the API is actually wired (not just the UI rendering)

Per the wiring guide: "the check that matters is whether changing the API
changes the screen." Create an incident via `POST /incidents` (Swagger
try-it-out, or `npm run check-api`) and confirm the Incidents screen's count
moves; approve an action and confirm two rows join the Audit trail;
`POST /_reset` and confirm both revert. A screen that doesn't move under
that test is rendering static markup, not live data.

## What's wired vs. scaffolded right now

This port focuses on getting the environment-driven API layer and the
wiring *pattern* right, with the **Today** screen fully wired end-to-end as
the reference (per the guide: "the model to copy"), and **Incidents (list)**,
**EOD (run timeline)**, **Audit (trail)**, **Corpus (resolutions)**, and
**Sources** (with the `Promise.allSettled` fan-out) also live. The
write path (propose/approve actions, capture/reuse resolutions) and a few
smaller reads are scaffolded with `TODO` comments pointing at the exact
guide section — see docs/API_WIRING.md for the complete, current checklist.
